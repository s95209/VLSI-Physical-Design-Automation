#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
using namespace std;
struct cell{
    float name;
    float width;
    float heigh;
    float x_coor;
    float y_coor;
    int fix;
    cell(){}
    cell(float n, float w, float h, float x, float y, int f){
        name = n;
        width = w;
        heigh = h;
        x_coor = x;
        y_coor = y;
        fix = f;
    }
};
struct cell_name{
    float name;
    float origin_x;
    float origin_y;
    float width;
    cell_name* next_cell_name;
    cell_name* pre_cell_name;
    cell_name(float n, float ox, float oy, float w){
        name = n;
        next_cell_name = NULL;
        pre_cell_name = NULL;
        width = w;
    }
};
struct cluster{
    float left_bound;
    float right_bound;
    float width;
    int num_of_cellname;
    cluster* next_cluster;
    cluster* pre_cluster;
    cluster* overlap_first;
    cluster* overlap_last;
    cell_name* first_cell_name;
    cell_name* last_cell_name;
    cluster(float l, float r, float w){
        num_of_cellname = 0;
        next_cluster = NULL;
        pre_cluster = NULL;
        first_cell_name = NULL;
        last_cell_name = NULL;
        overlap_first = NULL;
        overlap_last = NULL;
        left_bound = l;
        right_bound = r;
        width = w;
    }
};
struct row{
    float name;
    float left_bound;
    float right_bound;
    float coordinate;
    float row_width;
    float heigh;
    float space;
    row* next_row;
    row* pre_row;
    cluster* first_cluster;
    cluster* last_cluster;
    row(float l, float r, float w, float h, float c, float n){
        left_bound = l;
        right_bound = r;
        row_width = w;
        space = w;
        heigh = h;
        name = n;
        coordinate = c;
        next_row = NULL;
        pre_row = NULL;
        last_cluster = NULL;
        first_cluster = NULL;
    }
    row(float n){
        next_row = NULL;
        pre_row = NULL;
        name = n;
    }
};
bool x_coor_sort(cell* i, cell* j){
    return i->x_coor < j->x_coor;
}
bool terminal_coor_hei(cell* i, cell* j){
    return i->y_coor < j->y_coor;
}
bool check_overlap(row* try_row, float width){
    if(try_row->space >= width){    
        return 0;
    }
    else{
        return 1;
    }
}
cluster* temp_best_cluster(cluster* overlap_cluster, cluster* temp_cluster, int site, row* try_row){
    if(temp_cluster->left_bound < overlap_cluster->right_bound){ 
        if(temp_cluster->overlap_first == NULL){
            temp_cluster->overlap_first = overlap_cluster;
            temp_cluster->overlap_last = overlap_cluster;
        }
        else{
            temp_cluster->overlap_first = overlap_cluster;
        }
        float new_x_coor = float((int((overlap_cluster->num_of_cellname*overlap_cluster->left_bound + temp_cluster->num_of_cellname*(temp_cluster->left_bound - overlap_cluster->width))/(overlap_cluster->num_of_cellname + temp_cluster->num_of_cellname))/site)*site);
        float width = temp_cluster->width + overlap_cluster->width;
        if(new_x_coor < try_row->left_bound){
            new_x_coor = try_row->left_bound;
        }
        else if((new_x_coor + width) > try_row->right_bound){
            new_x_coor = try_row->right_bound - width;
        }
        temp_cluster->left_bound = new_x_coor;
        temp_cluster->width = width;
        temp_cluster->right_bound = temp_cluster->left_bound + width;
        temp_cluster->num_of_cellname = temp_cluster->num_of_cellname + overlap_cluster->num_of_cellname;
        
        cell_name* n_cell_name = overlap_cluster->last_cell_name;
        while(n_cell_name!= NULL){
            cell_name* new_cell_name = new cell_name(n_cell_name->name, n_cell_name->origin_x, n_cell_name->origin_y, n_cell_name->width);
            new_cell_name->next_cell_name = temp_cluster->first_cell_name;
            temp_cluster->first_cell_name->pre_cell_name = new_cell_name;
            temp_cluster->first_cell_name = new_cell_name;
            n_cell_name = n_cell_name->pre_cell_name;
        }
        if(overlap_cluster->pre_cluster != NULL){
            return temp_best_cluster(overlap_cluster->pre_cluster, temp_cluster, site, try_row);
        }
        else{
            if(temp_cluster->left_bound >= try_row->left_bound && temp_cluster->right_bound <= try_row->right_bound){
                return temp_cluster;
            }
            else{
                cell_name* next = temp_cluster->first_cell_name;
                while(next){
                    cell_name* temp = next;
                    next = next->next_cell_name;
                    delete temp;
                }
                delete temp_cluster;
                return NULL;
            }
        }
    }
    else{
        if(temp_cluster->left_bound >= try_row->left_bound && temp_cluster->right_bound <= try_row->right_bound){
            return temp_cluster;
        }
        else{
            cell_name* next = temp_cluster->first_cell_name;
            while(next){
                cell_name* temp = next;
                next = next->next_cell_name;
                delete temp;
            }
            delete temp_cluster;
            return NULL;
        }
    }
}
cluster* placerow(row* try_row, cell* insert_cell, float insert_cell_x, int site){
    if(check_overlap(try_row, insert_cell->width)){
            return NULL;
    }

    cluster* try_cluster = try_row->last_cluster;
    if(insert_cell_x < try_row->left_bound){
        insert_cell_x = try_row->left_bound;
    }
    else if((insert_cell_x + insert_cell->width) > try_row->right_bound){
        insert_cell_x = try_row->right_bound - insert_cell->width;
    }
    if(try_cluster != NULL){
        cluster* temp_cluster = new cluster(insert_cell_x, insert_cell_x+insert_cell->width, insert_cell->width);
        temp_cluster->num_of_cellname = 1;
        cell_name *fcell_name = new cell_name(insert_cell->name, insert_cell->x_coor, insert_cell->y_coor, insert_cell->width);
        fcell_name->next_cell_name = NULL;
        fcell_name->pre_cell_name = NULL;
        temp_cluster->first_cell_name = fcell_name;
        temp_cluster->last_cell_name = fcell_name;
        temp_cluster = temp_best_cluster(try_cluster, temp_cluster, site, try_row);
        return temp_cluster;
    }
    else{
        cluster* temp_cluster = new cluster(insert_cell_x, insert_cell_x+insert_cell->width, insert_cell->width);
        temp_cluster->num_of_cellname = 1;
        cell_name *fcell_name = new cell_name(insert_cell->name, insert_cell->x_coor, insert_cell->y_coor, insert_cell->width);
        fcell_name->next_cell_name = NULL;
        fcell_name->pre_cell_name = NULL;
        temp_cluster->first_cell_name = fcell_name;
        temp_cluster->last_cell_name = fcell_name;
        return temp_cluster;
    }
}
float count_x_cost(cluster* temp_cluster, float width, float row_y, float cell_x, float cell_y){
    float x_cost = fabs((temp_cluster->right_bound - width) - cell_x) + fabs(row_y - cell_y);
    return x_cost;
}

int main(int argc, char **argv){
    //read aux
    ifstream fileaaux(argv[1]);
    string line;
    vector<string> aux;
    while(getline(fileaaux, line)){
        stringstream ss(line);
        string word;
        while(ss >> word){
            aux.push_back(word);
        }
    }
    string file_path = argv[1];
    int sindex, endindex;
    endindex = file_path.length()-1;
    for(int i = endindex; i > 0; i--){
        if(argv[1][i] == '/'){
            sindex = i;
            break;
        }
    }
    file_path = file_path.erase(sindex+1,endindex-sindex);
    string node_path, pl_path, scl_path;
    float Max_displacement;
    node_path = file_path + aux[2];
    pl_path = file_path + aux[3];
    scl_path = file_path + aux[4];
    Max_displacement = stof(aux[7]);
    //////////////cell_arry//////////////////////////////////////////////////////////////////////////
    FILE *fnode = fopen(node_path.c_str(), "r");
    FILE *fpl = fopen(pl_path.c_str(), "r");
    FILE *fscl = fopen(scl_path.c_str(), "r");
    int NumNodes, NumTerminals, Numrows;
    fscanf(fnode, "%*s%*s%*c%d", &NumNodes);
    fscanf(fnode,"\n");
    fscanf(fnode, "%*s%*s%*c%d", &NumTerminals);
    fscanf(fnode,"\n");
    fscanf(fnode,"\n");
    cell* cell_arr[NumNodes];
    char head;
    for(int i = 0; i < NumNodes - NumTerminals; i++){
        float cell_name;
        float width;
        float heigh;
        float x_coor;
        float y_coor;
        fscanf(fnode, "%c%f %f %f\n", &head, &cell_name, &width, &heigh);
        fscanf(fpl, "%*c%*f %f %f %*[^\n]\n", &x_coor, &y_coor);
        cell* newcell = new cell(cell_name, width, heigh, x_coor, y_coor, 0);
        cell_arr[i] = newcell;
    }
    cell* terminal_arr[NumTerminals];
    for(int i = 0; i < NumTerminals; i++){
        float cell_name;
        float width;
        float heigh;
        float x_coor;
        float y_coor;
        fscanf(fnode, "%*c%f %f %f %*s\n", &cell_name, &width, &heigh);
        fscanf(fpl, "%*c%*f %f %f %*[^\n]\n", &x_coor, &y_coor);
        cell* newcell = new cell(cell_name, width, heigh, x_coor, y_coor, 1);
        terminal_arr[i] = newcell;
    }
    sort(&cell_arr[0], &cell_arr[NumNodes-NumTerminals], x_coor_sort);
    sort(&terminal_arr[0], &terminal_arr[NumTerminals], terminal_coor_hei);
    fscanf(fscl, "%*s %*s %d\n", &Numrows);
    fscanf(fscl,"\n");
    row** row_bucket = new row*[Numrows];
    for(int i = 0; i < Numrows; i++){
        row* new_row = new row(0);
        row_bucket[i] = new_row;
    }
    
    int site;
    for(int i = 0; i < Numrows; i++){
        float coordinate;
        float heigh;
        float sitewidth;
        float numsites;
        float suborigin;
        fscanf(fscl, "%*[^\n]\n");
        fscanf(fscl, "%*s %*s %f\n", &coordinate);
        fscanf(fscl, "%*s %*s %f\n", &heigh);
        fscanf(fscl, "%*s %*s %f\n", &sitewidth);
        fscanf(fscl, "%*s %*s %f\n", &numsites);
        fscanf(fscl, "%*s %*s %f\n", &suborigin);
        fscanf(fscl, "%*[^\n]\n");
        site = sitewidth;
        row* new_row = new row(suborigin, suborigin + sitewidth*numsites, sitewidth*numsites, heigh, coordinate, 1);
        row_bucket[i]->next_row = new_row;
        new_row->pre_row = row_bucket[i];
    }
    ////////////////////////////////////row_buck///////////////////////////////////////////
    
    for(int i = 0; i < NumTerminals; i++){
        float width = terminal_arr[i]->width;
        float heigh = terminal_arr[i]->heigh;
        float x_coor =  terminal_arr[i]->x_coor;
        float y_coor = terminal_arr[i]->y_coor;
        int row_index = (y_coor - row_bucket[0]->next_row->coordinate) / row_bucket[0]->next_row->heigh;
        int num_of_row = heigh / row_bucket[0]->next_row->heigh;
        for(int j = 0; j<num_of_row; j++){
            int temp_row_index = row_index + j;
            row* next_sub_row = row_bucket[temp_row_index]->next_row;
            while(next_sub_row != NULL){
                if(x_coor >= next_sub_row->left_bound && (x_coor + width) <= next_sub_row->right_bound){
                    row* subrow_l = new row(next_sub_row->left_bound, x_coor, x_coor-next_sub_row->left_bound, next_sub_row->heigh, next_sub_row->coordinate, 1);
                    row* subrow_r = new row(x_coor + width, next_sub_row->right_bound, next_sub_row->right_bound - (x_coor + width), next_sub_row->heigh, next_sub_row->coordinate, 1);
                    next_sub_row->pre_row->next_row = subrow_l;
                    subrow_l->pre_row = next_sub_row->pre_row;
                    subrow_l->next_row = subrow_r;
                    subrow_r->pre_row = subrow_l;
                    if(next_sub_row->next_row != NULL){
                        next_sub_row->next_row->pre_row = subrow_r;
                    }
                    subrow_r->next_row = next_sub_row->next_row;
                    delete next_sub_row;
                    break;
                }
                next_sub_row = next_sub_row->next_row;
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    cluster* best_cluster = NULL;
    row* best_row = NULL;
    int update = 0;
    float best_cost;
    float row_count = 10;
    for(int i = 0; i < NumNodes-NumTerminals; i++){
        cell* insert_cell = cell_arr[i];
        best_cost = 99999999999999999;
        for(int j = 0; j < Numrows; j++){
            row* next_sub_row = row_bucket[j]->next_row;
            while(next_sub_row){
                float insert_cell_x = float((int(insert_cell->x_coor) / site)*site);
                if(fabs(insert_cell->y_coor - next_sub_row->coordinate) < insert_cell->heigh*row_count ){
                    cluster* temp_cluster = placerow(next_sub_row ,insert_cell, insert_cell_x, site);
                    if(temp_cluster == NULL){
                        next_sub_row = next_sub_row->next_row;
                        continue;
                    }
                    //cout << count_x_cost(temp_cluster, insert_cell->width, next_sub_row->coordinate, insert_cell->x_coor, insert_cell->y_coor) << endl;
                    if( count_x_cost(temp_cluster, insert_cell->width, next_sub_row->coordinate, insert_cell->x_coor, insert_cell->y_coor) < best_cost){
                        update = 1;
                        best_cost = count_x_cost(temp_cluster, insert_cell->width, next_sub_row->coordinate, insert_cell->x_coor, insert_cell->y_coor);
                        best_cluster = temp_cluster;
                        best_row = next_sub_row;
                    }
                    else{
                        cell_name* next = temp_cluster->first_cell_name;
                        while(next){
                            cell_name* temp = next;
                            next = next->next_cell_name;
                            delete temp;
                        }
                        delete temp_cluster;
                    }
                    next_sub_row = next_sub_row->next_row;
                }
                else{
                    next_sub_row = next_sub_row->next_row;
                }
            }
        }
        
        if(update == 1){
            row_count = 10;
            update = 0;
            best_row->space = best_row->space - insert_cell->width;
            if(best_row->first_cluster == NULL){
                best_row->first_cluster = best_cluster;
                best_row->last_cluster = best_cluster;
            }
            else{
                cluster* temp_clu = NULL;
                if(best_cluster->overlap_first != NULL){
                    temp_clu = best_cluster->overlap_first;
                    if(temp_clu->pre_cluster != NULL){
                        temp_clu->pre_cluster->next_cluster = best_cluster;
                        best_cluster->pre_cluster = temp_clu->pre_cluster;
                        best_row->last_cluster = best_cluster;
                    }
                    else{
                        best_row->first_cluster = best_cluster;
                        best_row->last_cluster = best_cluster;
                    }
                    while(temp_clu){
                        cell_name* next_cn = temp_clu->first_cell_name;
                        while(next_cn){
                            cell_name* temp_c = next_cn;
                            next_cn = next_cn->next_cell_name;
                            delete temp_c;
                        }
                        cluster* del_cluster = temp_clu;
                        temp_clu = temp_clu->next_cluster;
                        delete del_cluster;
                    }
                }
                else{
                    best_row->last_cluster->next_cluster = best_cluster;
                    best_cluster->pre_cluster = best_row->last_cluster;
                    best_row->last_cluster = best_cluster;
                }
            }
        }
        else{
            i--;
            row_count = row_count + 10;
        }
    }
    FILE *out = fopen(argv[2], "w");
    for(int i = 0; i < Numrows; i++){
        row* next_r = row_bucket[i]->next_row;
        while(next_r){
            cluster* next_c = next_r->first_cluster;
            while(next_c){
                cell_name* next_n = next_c->first_cell_name;
                int out_x = int(next_c->left_bound);
                int out_y = int(next_r->coordinate);
                int name = int(next_n->name);
                while(next_n){
                    fprintf(out, "%c%d %d %d\n", head, name, out_x, out_y);
                    //fprintf(out, " width: %f", next_n->width);
                    //fprintf(out, "width: %f\n", next_n->width);
                    //fprintf(out, " %f %f %f\n", next_c->left_bound, next_c->right_bound, next_c->width);
                    out_x = out_x + int(next_n->width);
                    next_n = next_n->next_cell_name;
                    if(next_n != NULL){
                        name = next_n->name;
                    }
                }
                next_c = next_c->next_cluster;
            }
            next_r = next_r->next_row;
        }
    }
    for(int i = 0; i<NumTerminals; i++){
        int name = int(terminal_arr[i]->name);
        int x = int(terminal_arr[i]->x_coor);
        int y = int(terminal_arr[i]->y_coor);
        fprintf(out, "%c%d %d %d\n", head, name, x, y);
    }
}