#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <math.h>
#include <time.h>
#include <algorithm>
using namespace std;
struct xy{
    int x;
    int y;
    xy(int f, int s){
        x = f;
        y = s;
    }
    xy(){}
};
struct output_xy{
    int x;
    int y;
    int rota;
    output_xy(){}
};
struct node{
    int name;
    int rota;
    int type;
    xy model_xy;
    node *next;
    node *pre;
    node *from_l;
    node *from_r;
    int width;
    int heigh;
    node(){
        pre = NULL;
        next = NULL;
        from_l = NULL;
        from_r = NULL;
        rota = 0;
    }
    node(int w, int h){
        pre = NULL;
        next = NULL;
        from_l = NULL;
        from_r = NULL;
        rota = 0;
        width = w;
        heigh = h;
    }
};
struct VH{
    int type;
    xy VHcoor;
    int lord;
    int roru;
    node *front;
    node *back;
    VH(){
        front = NULL;
        back = NULL;
    }
    void clean(){
        front = NULL;
        back = NULL;
    }
};
struct netnode{
    int name;
    int type;
    netnode *next;
    netnode(int n, int t){
        name = n;
        type = t; //p==1 , sb==2
        next = NULL;
    }
};
int hard_hei[410];
xy pincoor[1000000];
xy blockcenter[410];
output_xy templeftdowncoor[410];
output_xy bestleftdowncoor[410];
int blockrota[410];
node* blockWH[400];
int polish[800];
int temppolish[810];
int bestpolish[810];
int stack[410];
VH VHtemp[410];
float pre_cost = 900000000;
float ratio;
float delta_cost;
float tempfloorarea;
float tempwidth;
float tempheigh;
void compute_coor(node* root, xy father_xy, int type){
    if(type == -1){
        root->from_l->model_xy.x = father_xy.x;
        root->from_l->model_xy.y = father_xy.y;
        root->from_r->model_xy.x = father_xy.x + root->from_l->width;
        root->from_r->model_xy.y = father_xy.y;
    }
    else if(type == -2){
        root->from_l->model_xy.x = father_xy.x;
        root->from_l->model_xy.y = father_xy.y;
        root->from_r->model_xy.x = father_xy.x;
        root->from_r->model_xy.y = father_xy.y + root->from_l->heigh;
    }
    if(root->from_l->type == 0){
        xy temp_xp = root->from_l->model_xy;
        temp_xp.x = temp_xp.x + (root->from_l->width/2);
        temp_xp.y = temp_xp.y + (root->from_l->heigh/2);
        blockcenter[root->from_l->name] = temp_xp;
        templeftdowncoor[root->from_l->name].x = root->from_l->model_xy.x;
        templeftdowncoor[root->from_l->name].y = root->from_l->model_xy.y;
        templeftdowncoor[root->from_l->name].rota = root->from_l->rota;
    }
    if(root->from_r->type == 0){
        xy temp_xp = root->from_r->model_xy;
        temp_xp.x = temp_xp.x + (root->from_r->width/2);
        temp_xp.y = temp_xp.y + (root->from_r->heigh/2);
        blockcenter[root->from_r->name] = temp_xp;
        templeftdowncoor[root->from_r->name].x = root->from_r->model_xy.x;
        templeftdowncoor[root->from_r->name].y = root->from_r->model_xy.y;
        templeftdowncoor[root->from_r->name].rota = root->from_r->rota;
    }
    if(root->from_l->type != 0){
        compute_coor(root->from_l, root->from_l->model_xy, root->from_l->type);
    }
    if(root->from_r->type != 0){
        compute_coor(root->from_r, root->from_r->model_xy, root->from_r->type);
    }
}
node* compute_area(int hardblock){
    int top = 0;
    int rumodel, ldmodel;
    int VHcount = -1;
    for(int k = 0; k < hardblock*2-1; k++){
        if(polish[k] != -1 && polish[k] != -2){
            stack[top] = polish[k];
            top = top + 1; 
        }
        else{
            rumodel = stack[top-1];
            ldmodel = stack[top-2];
            node *ldpointer = NULL;
            node *rupointer = NULL;
            top = top - 2;
            stack[top] = VHcount;
            top = top + 1;

            VH* VHptr = &VHtemp[-VHcount];
            VHptr->clean();

            VHptr->lord = ldmodel;
            VHptr->roru = rumodel;
            if(polish[k] == -1){
                VHptr->type = -1;
                if(ldmodel >= 0){
                    ldpointer = blockWH[ldmodel];
                }
                else{
                    ldpointer = VHtemp[-ldmodel].front;
                }

                if(rumodel >= 0){
                    rupointer = blockWH[rumodel];
                }
                else{
                    rupointer = VHtemp[-rumodel].front;
                }
            }
            else if(polish[k] == -2){
                VHptr->type = -2;
                if(ldmodel >= 0){
                    if(blockWH[ldmodel]->next != NULL){
                        ldpointer = blockWH[ldmodel]->next;
                    }
                    else{
                        ldpointer = blockWH[ldmodel];
                    }
                }
                else{
                    ldpointer = VHtemp[-ldmodel].back;
                }
                if(rumodel >= 0){
                    if(blockWH[rumodel]->next != NULL){
                        rupointer = blockWH[rumodel]->next;
                    }
                    else{
                        rupointer = blockWH[rumodel];
                    }  
                }
                else{
                    rupointer = VHtemp[-rumodel].back;
                }
            }
            if(polish[k] == -1){
                while(ldpointer != NULL && rupointer != NULL){
                    if(ldpointer->heigh > rupointer->heigh){
                        node* nvhn = new node( (ldpointer->width + rupointer->width) , ldpointer->heigh );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -1;
                        if(VHptr->back == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->pre = VHptr->back;
                            VHptr->back->next = nvhn;
                            VHptr->back = nvhn;
                        }
                        ldpointer = ldpointer->next;
                    }
                    else if(rupointer->heigh > ldpointer->heigh){
                        node* nvhn = new node( (rupointer->width + ldpointer->width) , rupointer->heigh );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -1;
                        if(VHptr->back == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->pre = VHptr->back;
                            VHptr->back->next = nvhn;
                            VHptr->back = nvhn;
                        }
                        rupointer = rupointer->next;
                    }
                    else if(ldpointer->heigh == rupointer->heigh){
                        node* nvhn = new node( (rupointer->width + ldpointer->width) , ldpointer->heigh );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -1;
                        if(VHptr->back == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->pre = VHptr->back;
                            VHptr->back->next = nvhn;
                            VHptr->back = nvhn;
                        }
                        ldpointer = ldpointer->next;
                        rupointer = rupointer->next;
                    }
                }  
            }
            else if(polish[k] == -2){
                while(ldpointer != NULL && rupointer != NULL){
                    if(ldpointer->width > rupointer->width){
                        node* nvhn = new node( ldpointer->width , (ldpointer->heigh + rupointer->heigh) );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -2;
                        if(VHptr->front == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->next = VHptr->front;
                            VHptr->front->pre = nvhn;
                            VHptr->front = nvhn;
                        }
                        ldpointer = ldpointer->pre;
                    }
                    else if(rupointer->width > ldpointer->width){
                        node* nvhn = new node( rupointer->width , (ldpointer->heigh + rupointer->heigh) );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -2;
                        if(VHptr->front == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->next = VHptr->front;
                            VHptr->front->pre = nvhn;
                            VHptr->front = nvhn;
                        }
                        rupointer = rupointer->pre;
                    }
                    else if(rupointer->width == ldpointer->width){
                        node* nvhn = new node( ldpointer->width , (ldpointer->heigh + rupointer->heigh) );
                        nvhn->from_l = ldpointer;
                        nvhn->from_r = rupointer;
                        nvhn->name = VHcount;
                        nvhn->type = -2;
                        if(VHptr->front == NULL){
                            VHptr->front = nvhn;
                            VHptr->back = nvhn;
                        }
                        else{
                            nvhn->next = VHptr->front;
                            VHptr->front->pre = nvhn;
                            VHptr->front = nvhn;
                        }
                        ldpointer = ldpointer->pre;
                        rupointer = rupointer->pre;
                    }
                }
            }
            VHcount--;
        }
    }   
    node *n = VHtemp[hardblock-1].front;
    node *root = n;
    tempfloorarea = n->width*n->heigh;
    tempwidth = n->width;
    tempheigh = n->heigh;
    n = n->next;
    while(n != NULL){
        if(float(n->heigh*n->width) < tempfloorarea){
            tempfloorarea = float(n->heigh * n->width);
            tempwidth = n->width;
            tempheigh = n->heigh;
            root = n;
        }
        n = n->next;
    }
    root->model_xy.x = 0;
    root->model_xy.y = 0;
    return root;
}
void compute_wirelength(netnode** &net, int* &netlen, int numnet){
    netnode* n = NULL;
    int max_x, max_y, min_x, min_y; 
    for(int i = 0; i < numnet; i++){
        n = net[i];
        if(n->type == 1){
            max_x = pincoor[n->name].x;
            min_x = pincoor[n->name].x;
            max_y = pincoor[n->name].y;
            min_y = pincoor[n->name].y;
        }
        else{
            max_x = blockcenter[n->name].x;
            min_x = blockcenter[n->name].x;
            max_y = blockcenter[n->name].y;
            min_y = blockcenter[n->name].y;
        }
        n = n->next;
        while(n != NULL){
            if(n->type == 1){
                if(pincoor[n->name].x > max_x){
                    max_x = pincoor[n->name].x;
                }
                if(pincoor[n->name].y > max_y){
                    max_y = pincoor[n->name].y;
                }
                if(pincoor[n->name].x < min_x){
                    min_x = pincoor[n->name].x;
                }
                if(pincoor[n->name].y < min_y){
                    min_y = pincoor[n->name].y;
                }
            }
            else{
                if(blockcenter[n->name].x > max_x){
                    max_x = blockcenter[n->name].x;
                }
                if(blockcenter[n->name].y > max_y){
                    max_y = blockcenter[n->name].y;
                }
                if(blockcenter[n->name].x < min_x){
                    min_x = blockcenter[n->name].x;
                }
                if(blockcenter[n->name].y < min_y){
                    min_y = blockcenter[n->name].y;
                }
            }
            n = n->next;
        }
        netlen[i] = (max_x - min_x) + (max_y - min_y);
    }
}
void disturb(int x, int hardblock){
    if(x <= 33){
        //case1
        int pos = rand()%(hardblock-1)+1;
        int count = pos;
        int c1,c2;
        for(int p = 0; p < hardblock*2-1; p++){
            if(polish[p] != -1 && polish[p] != -2)
                count--;
            if(count == 0){
                c1 = p;
                break;
            } 
        }
        count = 1;
        for(int p = c1+1; p < hardblock*2-1; p++){
            if(polish[p] != -1 && polish[p] != -2)
                count--;
            if(count == 0){
                c2 = p;
                break;
            }
        }
        int temp = polish[c1];
        polish[c1] = polish[c2];
        polish[c2] = temp;
    }
    else if(x <= 66){
        //case2
        int posofc = rand()%(hardblock-1)+1;
        int countc = posofc;
        int chain_s, chain_e;
        for(int p = 0; p < hardblock*2-1; p++){
            if(polish[p] == -1 || polish[p] == -2){
                countc--;
            }
            if(countc == 0){
                chain_s = p;
                chain_e = p;
                break;
            }
        }
        for(int p = 0; p < hardblock*2-1; p++){
            if(chain_s-1 < 0)
                break;
            if(polish[chain_s-1] == -1 || polish[chain_s-1] == -2){
                chain_s = chain_s - 1;
            }
            else{
                break;
            }
        }
        for(int p = 0; p < hardblock*2-1; p++){
            if(chain_e+1 > hardblock*2-2)
                break;
            if(polish[chain_e + 1] == -1 || polish[chain_e + 1] == -2){
                chain_e = chain_e + 1;
            }
            else{
                break;
            }
        }
        for(int p = chain_s; p <= chain_e; p++){
            if(polish[p] == -1)
                polish[p] = -2;
            else
                polish[p] = -1;
        }
    }
    else{
        //case3
        int pos = rand()%(hardblock*2-2);
        int c1, c2;
        int vio = 1;
        while(vio){
            while(1){   
                pos = pos % (hardblock*2-2);
                c1 = pos;
                if(polish[c1] == -1 || polish[c1] == -2){
                    if(polish[c1+1] != -1 && polish[c1+1] != -2){
                        c2 = c1+1;
                        break;
                    }
                    else{
                        pos++;
                    }
                }
                else{
                    if(polish[c1+1] == -1 || polish[c1+1] == -2){
                        c2 = c1+1;
                        break;
                    }
                    else{
                        pos++;
                    }
                }
            }
            int torcount = 0;
            for(int k = 0; k <= c2; k++){
                if(polish[k] == -1 || polish[k] == -2){
                    torcount++;
                }
            }
            if(torcount*2 < c1+1){
                vio = 0;
            }
            pos++;
        }
        int temp = polish[c1];
        polish[c1] = polish[c2];
        polish[c2] = temp;
    }
}
void release_node(int hardblock){
    for(int i = 1; i < hardblock; i++){
        node* nex = NULL;
        if(VHtemp[i].front != NULL){
            nex = VHtemp[i].front;
        }
        while(nex != NULL){
            node* temp_del;
            temp_del = nex;
            nex = nex->next;
            delete temp_del;
        }
    }
}
bool hei(int i, int j){
    return blockWH[i]->heigh > blockWH[j]->heigh;
}
char file_name[100];

int main(int argc, char **argv){
    string fname = argv[1];
    int send,shead;
    for(int i = fname.size()-1; i>0; i--){
        if(fname[i] == '.') send = i;
        if(fname[i] == 'n'){
            shead = i;
            break;
        }
    }
    copy(&fname[shead], &fname[send], begin(file_name));
    string str_filename(file_name);
    clock_t start_time, end_time, temp_time;
    start_time = clock();
    /////////////////////////////////read hardblock///////////////////////////////////
    int hardblock;
    int terminal;
    FILE *fhb = fopen(argv[1], "r");
    fscanf(fhb,"%*s%*s %d", &hardblock);
    fscanf(fhb,"%*s%*s %d", &terminal);
    fscanf(fhb,"\n");
    float blockarea = 0;
    for(int i = 0; i < hardblock; i++){
        int tx = 0, ty = 0;
        fscanf(fhb,"%*s%*s%*s");
        for(int j = 0; j < 4; j++){
            fscanf(fhb," %*c%d%*c ", &tx);
            fscanf(fhb,"%d%*c", &ty);
            if(j == 2){
                blockarea = blockarea + (tx * ty);
                if(tx == ty){
                    node* nf = new node(tx , ty);
                    nf->type = 0;
                    nf->name = i;
                    nf->rota = 0;
                    blockWH[i] = nf;
                }
                else if(tx > ty){
                    node* nf = new node(ty , tx);
                    nf->type = 0;
                    nf->name = i;
                    nf->rota = 1;
                    blockWH[i] = nf;
                    node* ns = new node(tx , ty);
                    ns->type = 0;
                    ns->name = i;
                    ns->rota = 0;
                    nf->next = ns;
                    ns->pre = nf;
                }
                else{
                    node* nf = new node(tx , ty);
                    nf->type = 0;
                    nf->name = i;
                    nf->rota = 0;
                    blockWH[i] = nf;
                    node* ns = new node(ty , tx);
                    ns->type = 0;
                    ns->name = i;
                    ns->rota = 1;
                    nf->next = ns;
                    ns->pre = nf;
                }  
                
            }
        }
    }
    fscanf(fhb,"\n");
    float floorplan_ratio = atof(argv[5]) + 1;
    double outlinearea = double(blockarea*floorplan_ratio);
    int floorplan_hw = int( sqrt(outlinearea) );

    /////////////////////////////////read net////////////////////////////////////////
    int numnet;
    int numpins;
    int netdeg;
    int nodename;
    char nodechar[1000];
    FILE *fn = fopen(argv[2], "r");
    fscanf(fn,"%*s%*s %d", &numnet);
    fscanf(fn,"%*s%*s %d", &numpins);
    netnode **netarray = new netnode*[numnet];
    int *netlength = new int[numnet];
    for(int i=0; i<numnet; i++){
        netarray[i] = NULL;
    }
    int numpin = 0;
    for(int i=0; i<numnet; i++){
        fscanf(fn,"%*s%*s %d", &netdeg);
        numpin = numpin + netdeg;
        for(int j=0; j<netdeg; j++){
            fscanf(fn,"%s",nodechar);
            netnode *Nnetnode = NULL;
            if(nodechar[0] == 'p'){
                copy(&nodechar[1], end(nodechar), begin(nodechar));
                nodename = atoi(nodechar);
                Nnetnode = new netnode(nodename, 1);
            }
            else if(nodechar[0] == 's'){
                copy(&nodechar[2], end(nodechar), begin(nodechar));
                nodename = atoi(nodechar);
                Nnetnode = new netnode(nodename, 2);
            }
            if(netarray[i] == NULL){
                netarray[i] = Nnetnode;
            }
            else{
                Nnetnode->next = netarray[i];
                netarray[i] = Nnetnode;
            }
        }
    }
    /////////////////////////////////read terminal////////////////////////////////////
    FILE *ft = fopen(argv[3], "r");
    int p_x, p_y;
    for(int i=1; i<=terminal; i++){
        fscanf(ft,"%*s %d %d", &p_x, &p_y);
        pincoor[i].x = p_x;
        pincoor[i].y = p_y;
    }    

    ///////////////////////////create polish///////////////////////////////////////////
    // -1 is V, -2 is H
    for(int i = 0; i < hardblock; i++){
        hard_hei[i] = i;
    }
    sort(hard_hei, hard_hei+hardblock, hei);
    int widddd = 0;
    int canh = 0;
    polish[0] = hard_hei[0];
    widddd = widddd + blockWH[hard_hei[0]]->width;
    int j = 1, l = 0;
    int k;
    for(int i = 1; i < hardblock; i++){
        if( (widddd + blockWH[hard_hei[i]]->width) <  floorplan_hw){
            widddd = widddd + blockWH[hard_hei[i]]->width;
            polish[j] = hard_hei[i];
            j = j + 1;
            polish[j] = -1;
            j = j + 1;
        }
        else{
            
            k = i + 1;
            l = 0;
            if(k < hardblock){
                while(blockWH[hard_hei[i]]->heigh == blockWH[hard_hei[k]]->heigh){
                    if( (widddd + blockWH[hard_hei[k]]->width) <  floorplan_hw){
                        l = 1;
                        widddd = widddd + blockWH[hard_hei[k]]->width;
                        polish[j] = hard_hei[k];
                        j = j + 1;
                        polish[j] = -1;
                        j = j + 1;
                        hard_hei[k] = hard_hei[i];
                        break;
                    }
                    if(k + 1 < hardblock){
                        k = k + 1;
                    }
                    else{
                        break;
                    }
                }
                if(l == 0){
                    widddd = 0;
                    if(canh == 0){
                        polish[j] = hard_hei[i];
                        j = j + 1;
                        canh = 1;
                    }
                    else{
                        polish[j] = -2;
                        j = j + 1;
                        polish[j] = hard_hei[i];
                        j = j + 1;
                    }
                    widddd = widddd + blockWH[hard_hei[i]]->width;
                }
            }
            else{
                widddd = 0;
                if(canh == 0){
                    polish[j] = hard_hei[i];
                    j = j + 1;
                    canh = 1;
                }
                else{
                    polish[j] = -2;
                    j = j + 1;
                    polish[j] = hard_hei[i];
                    j = j + 1;
                }
                widddd = widddd + blockWH[hard_hei[i]]->width;
            }
        }
    }
    polish[2*hardblock-2] = -2;
    //////////////////////////////Disturb caculate area////////////////////////////////////

    unsigned int seed = time(NULL);
    if(str_filename == "n200"){
        seed = 1669816933;
    }
    float overtime = 590;
    srand(seed);
    float total_sol_gen = 0;
    float uphill = 0;
    float reject = 0;
    float min_area;
    float min_wid;
    float min_hei;
    int min_wirelen;
    int onetemp;
    float min_cost;
    float bestcost = floorplan_hw * floorplan_hw;
    float iniP = 0.99999;
    float inidelcost = 10000000;
    float temperature;
    float changepoint = 0.6 * temperature;
    float random;
    float cost;
    float rate = 0.9;
    float tp_to_wlen;
    float area_nomal_fac = 0;
    float wire_nomal_fac = 0;
    float areaweight = 0;
    float over_hei;
    float over_wid;
    float areacost;
    float A_W_cost;
    int over = 1;
    int fixoutline;
    copy(&polish[0], &polish[hardblock*2-1], &temppolish[0]);
    for(int i = 0; i < 1000; i++){
        int x = rand()%100;
        disturb(x,hardblock);
        node* root = compute_area(hardblock);
        compute_coor(root, root->model_xy, root->type);
        release_node(hardblock);
        compute_wirelength(netarray, netlength, numnet);
        tp_to_wlen = 0;
        for(int b = 0; b < numnet; b++){
            tp_to_wlen = tp_to_wlen + netlength[b];
        }
        wire_nomal_fac = wire_nomal_fac + tp_to_wlen;
        area_nomal_fac = area_nomal_fac + tempfloorarea;
    }
    wire_nomal_fac = wire_nomal_fac / 1000;
    area_nomal_fac = area_nomal_fac / 1000;

    copy(&temppolish[0], &temppolish[hardblock*2-1], &polish[0]);

    node* root = compute_area(hardblock);
    compute_coor(root, root->model_xy, root->type);
    release_node(hardblock);
    compute_wirelength(netarray, netlength, numnet);
    tp_to_wlen = 0;
    for(int b = 0; b < numnet; b++){
        tp_to_wlen = tp_to_wlen + netlength[b];
    }
    areacost = tempfloorarea;
    over_hei = 0;
    over_wid = 0;
    over_hei = tempheigh - (floorplan_hw-1);
    over_wid = tempwidth - (floorplan_hw-1);
    if(max(over_hei , over_wid) >= 0)
        fixoutline = max(over_hei , over_wid) * max(over_hei , over_wid);
    else
        fixoutline = 0;
    

    if(tempheigh <= floorplan_hw && tempwidth <= floorplan_hw){
       over = 0;  
       A_W_cost = areaweight*(areacost / area_nomal_fac) + (1-areaweight)*(tp_to_wlen / wire_nomal_fac);      
    }
    else{
        A_W_cost = 1;
    }

    cost = A_W_cost + fixoutline;
    bestcost = cost;
    pre_cost = cost;
    min_cost = cost;
    min_area = tempfloorarea;
    min_hei = tempheigh;
    min_wid = tempwidth;
    min_wirelen = tp_to_wlen;
    copy(begin(templeftdowncoor), end(templeftdowncoor), begin(bestleftdowncoor));
    copy(&polish[0], &polish[hardblock*2-1], &bestpolish[0]);
    temperature = (-cost)*100000 / (log(iniP));


    while(over){
        onetemp = 1;
        uphill = 0;
        reject = 0;
        total_sol_gen = 0;
        while(onetemp){
            copy(&polish[0], &polish[hardblock*2-1], &temppolish[0]);
            int x = rand()%100;
            disturb(x,hardblock);
            total_sol_gen++;
            node* root = compute_area(hardblock);
            compute_coor(root, root->model_xy, root->type);
            release_node(hardblock);
            compute_wirelength(netarray, netlength, numnet);
            tp_to_wlen = 0;
            for(int b = 0; b < numnet; b++){
                tp_to_wlen = tp_to_wlen + netlength[b];
            }
            areacost = tempfloorarea;
            over_hei = 0;
            over_wid = 0;
            over_hei = tempheigh - (floorplan_hw-1);
            over_wid = tempwidth - (floorplan_hw-1);
            fixoutline = max(over_hei , over_wid) * max(over_hei , over_wid);
            if(tempheigh <= floorplan_hw && tempwidth <= floorplan_hw){
                over = 0;     
                A_W_cost = areaweight*(areacost / area_nomal_fac) + (1-areaweight)*(tp_to_wlen / wire_nomal_fac);      
            }
            else{
                A_W_cost = 1;
            }
            cost = A_W_cost + fixoutline;
            delta_cost = cost - pre_cost;
            random = float(rand()%1000000+1)/1000000;
            if(delta_cost <= 0 || random < exp( (-delta_cost) / temperature )){
                if(delta_cost > 0){
                    uphill++;
                }
                pre_cost = cost;
                if(over_hei <= 1 && over_wid <= 1){
                    min_cost = cost;
                    min_area = tempfloorarea;
                    min_hei = tempheigh;
                    min_wid = tempwidth;
                    min_wirelen = tp_to_wlen;
                    copy(begin(templeftdowncoor), end(templeftdowncoor), begin(bestleftdowncoor));
                    copy(&polish[0], &polish[hardblock*2-1], &bestpolish[0]);
                    onetemp = 0;
                    over = 0;
                }
                if(cost < bestcost){
                    bestcost = cost;
                }
            }
            else{
                copy(&temppolish[0], &temppolish[hardblock*2-1], &polish[0]);
                reject++;
            }
            if(total_sol_gen > 40*hardblock || uphill > hardblock){
                onetemp = 0;
            }
        }

        if(temperature > changepoint){
            rate = 0.9;
        }
        else if(temperature > 1){
            rate = 0.99;
        }
        
        temperature = temperature * rate;
        
        temp_time = clock();
        if(((reject/total_sol_gen) > 0.95 || temperature < 0.1) || double(temp_time-start_time)/CLOCKS_PER_SEC > 590)
        {   
            if(double(temp_time-start_time)/CLOCKS_PER_SEC > 596){
                over = 0;
            }
            else{
                if(min_hei <= floorplan_hw && min_wid <= floorplan_hw){
                    over = 0;            
                }
                else{
                    over = 1; 
                }
            }
        }
    }

    FILE *out = fopen(argv[4], "w");
    fprintf(out, "%s %d%s", "Wirelength", min_wirelen, "\n");
    fprintf(out, "%s", "Blocks\n");
    for(int i = 0; i < hardblock; i++){
        fprintf(out, "%s%d %d %d %d%s", "sb", i, bestleftdowncoor[i].x, bestleftdowncoor[i].y, bestleftdowncoor[i].rota, "\n");
    }
    
    
    
    str_filename = "./" + str_filename + "_" +to_string(floorplan_ratio) + ".txt";
    FILE *o = fopen(str_filename.c_str(), "w");
    fprintf(o, "%s %f %s %f%s","block_area :" , blockarea , "Minarea:", min_area, "\n");
    end_time = clock();
}