#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
using namespace std;

#define CS_WIDTH 7100
#define CS_HEIGHT 6600
#define M3_WIDTH 440
#define M3_SPACING 310
#define M4_WIDTH 1000
#define M4_SPACING 490
#define CS_X1_TO_DRAIN 1260
#define CS_Y1_TO_DRAIN 4100
#define CS_LIB_NAME "MSBCS"
#define VIA34_LIB_NAME "Via34"

class Die{
    public:
        string design_name;
        int x1, x2, y1, y2;
        Die(string design_name, int x1, int y1, int x2, int y2){
            this->x1 = x1;
            this->x2 = x2;
            this->y1 = y1;
            this->y2 = y2;
            this->design_name = design_name;
        }
};
class Component{
    public:
        string lib_name;
        string inst_name;
        int x, y;
        Component(){}
        Component(string lib_name, string inst_name, int x, int y){
            this->lib_name = lib_name;
            this->inst_name = inst_name;
            this->x = x;
            this->y = y;
        }
};
class SpecialNet{
    public:
        string inst_name;
        string layer;
        int x1, x2, y1, y2;
        SpecialNet(){}
        SpecialNet(string inst_name, string layer, int x1, int y1, int x2, int y2){
            this->inst_name = inst_name;
            this->layer = layer;
            this->x1 = x1;
            this->x2 = x2;
            this->y1 = y1;
            this->y2 = y2;
        }
};

void write_def(string& def_name, Die& die, vector<Component>& component_list, vector<SpecialNet>& specialnet_list){
    ofstream out;
    out.open(def_name);
    out << "VERSION 5.6 ;\n";
    out << "DIVIDERCHAR \"/\" ;\n";
    out << "BUSBITCHARS \"[]\" ;\n";
    out << "DESIGN " << die.design_name << " ;\n\n";
    out << "UNITS DISTANCE MICRONS 1000 ;\n\n";
    out << "PROPERTYDEFINITIONS\n";
    out << "  COMPONENTPIN text STRING ;\n";
    out << "END PROPERTYDEFINITIONS\n\n";
    out << "DIEAREA ( " << die.x1 << " " << die.y1 << " ) ( " << die.x2 << " " << die.y2 << " ) ;\n\n";
    if(!component_list.empty()){
        out << "COMPONENTS " << component_list.size() << " ;\n";
        for(auto component:component_list){
            out << "- " << component.inst_name << " " << component.lib_name << "\n";
            out << "  + PLACED ( " << component.x << " " << component.y << " ) N ;\n";
        }
    }
    out << "END COMPONENTS\n\n";
    if(!specialnet_list.empty()){
        out << "SPECIALNETS " << specialnet_list.size() << " ;\n";
        for(auto specialNet:specialnet_list){
            if(specialNet.layer == "ME3"){
                string name = specialNet.inst_name;
                int x = (specialNet.x1 + specialNet.x2) / 2;
                int y1 = specialNet.y1;
                int y2 = specialNet.y2;
                out << "- " << name << "\n";
                out << "  + ROUTED ME3 440 ( " << x << " " << y1 << " ) ( * " << y2 << " ) ;\n";
            }
            else if(specialNet.layer == "ME4"){
                string name = specialNet.inst_name;
                int x1 = specialNet.x1;
                int x2 = specialNet.x2;
                int y = (specialNet.y1 + specialNet.y2) / 2;
                out << "- " << name << "\n";
                out << "  + ROUTED ME4 1000 ( " << x1 << " " << y << " ) ( " << x2 << " * ) ;\n";
            }
        }
        out << "END SPECIALNETS\n\n";
    }
    out << "END DESIGN\n";
}

int main(int argc, char** argv){

    int sorce_num = atoi(argv[1]);
    int cs_per_slide = sqrt(sorce_num*4);
    int m3_num = sqrt(sorce_num);
    int m4_num = m3_num / 2;
    //Step 1: create die boundary
    string design_name = "CS_APR";
    int die_x1 = 0;
    int die_y1 = 0;
    int die_x2 = CS_WIDTH*cs_per_slide + M3_SPACING*((m3_num+1)*cs_per_slide - 1) + M3_WIDTH*(m3_num*cs_per_slide);
    int die_y2 = CS_HEIGHT*cs_per_slide + M4_SPACING*((m4_num+1)*cs_per_slide - 1) + M4_WIDTH*(m4_num*cs_per_slide);
    Die die(design_name, die_x1, die_y1, die_x2, die_y2);
    //Step 2: create CS array
    int Dx = CS_WIDTH + M3_SPACING*(m3_num+1) + M3_WIDTH*m3_num;
    int Dy = CS_HEIGHT + M4_SPACING*(m4_num+1) + M4_WIDTH*m4_num;
    int offy = M4_SPACING*m4_num + M4_WIDTH*m4_num;
    Component** cs_array = new Component*[cs_per_slide];
    for(int i = 0; i < cs_per_slide; i++) cs_array[i] = new Component[cs_per_slide];
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < cs_per_slide; j++){
            string cs_lib_name = CS_LIB_NAME;
            string cs_instance_name = "Transistor" + to_string(i*cs_per_slide + j);
            int x = i*Dx;
            int y = j*Dy + offy;
            cs_array[i][j] = Component(cs_lib_name, cs_instance_name, x, y);
        }
    }

    //Step 3: create vertical ME3
    //ME3 nets
    int px = M3_WIDTH + M3_SPACING;
    Dx = CS_WIDTH + M3_SPACING;
    SpecialNet** ME3_specialnet = new SpecialNet*[cs_per_slide];
    for(int i = 0; i < cs_per_slide; i++) ME3_specialnet[i] = new SpecialNet[m3_num];
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < m3_num; j++){
            string inst_name = "Metal3_" + to_string(i*m3_num + j);
            string layer = "ME3";
            int x1 = cs_array[i][0].x + Dx + j*px;
            int x2 = x1 + M3_WIDTH;
            int y1 = 0;
            int y2 = die_y2;
            ME3_specialnet[i][j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
        }
    }
    //Step 4: create ME4 drain
    //ME4 drains
    int num_m4_drain = sqrt(sorce_num);
    SpecialNet** ME4_specialnet_drain = new SpecialNet*[cs_per_slide];
    for(int i = 0; i < cs_per_slide; i++) ME4_specialnet_drain[i] = new SpecialNet[cs_per_slide];
    for(int i = 0; i < num_m4_drain; i++){
        for(int j = 0; j < num_m4_drain; j++){
            string layer = "ME4";
            //left bottom corner units
            string inst_name = "Metal4_drain_" + to_string(i*num_m4_drain + j + 0*sorce_num);
            int x1 = cs_array[i][j].x + CS_X1_TO_DRAIN;
            int x2 = ME3_specialnet[i][j].x2;
            int y1 = cs_array[i][j].y + CS_Y1_TO_DRAIN;
            int y2 = y1 + M4_WIDTH;
            ME4_specialnet_drain[i][j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
            //right bottom corner units
            inst_name = "Metal4_drain_" + to_string(i*num_m4_drain + j + 1*sorce_num);
            x1 = cs_array[(cs_per_slide-1)-i][j].x + CS_X1_TO_DRAIN;
            x2 = ME3_specialnet[(cs_per_slide-1)-i][j].x2;
            y1 = cs_array[(cs_per_slide-1)-i][j].y + CS_Y1_TO_DRAIN;
            y2 = y1 + M4_WIDTH;
            ME4_specialnet_drain[(cs_per_slide-1)-i][j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
            //left top corner units
            inst_name = "Metal4_drain_" + to_string(i*num_m4_drain + j + 2*sorce_num);
            x1 = cs_array[i][(cs_per_slide-1)-j].x + CS_X1_TO_DRAIN;
            x2 = ME3_specialnet[i][j].x2;
            y1 = cs_array[i][(cs_per_slide-1)-j].y + CS_Y1_TO_DRAIN;
            y2 = y1 + M4_WIDTH;
            ME4_specialnet_drain[i][(cs_per_slide-1)-j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
            //right top corner units
            inst_name = "Metal4_drain_" + to_string(i*num_m4_drain + j + 3*sorce_num);
            x1 = cs_array[(cs_per_slide-1)-i][(cs_per_slide-1)-j].x + CS_X1_TO_DRAIN;
            x2 = ME3_specialnet[(cs_per_slide-1)-i][j].x2;
            y1 = cs_array[(cs_per_slide-1)-i][(cs_per_slide-1)-j].y + CS_Y1_TO_DRAIN;
            y2 = y1 + M4_WIDTH;
            ME4_specialnet_drain[(cs_per_slide-1)-i][(cs_per_slide-1)-j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
        }
    }
    
    //Step 5: create ME4 port
    //ME4 ports
    SpecialNet* ME4_specialnet_port = new SpecialNet[m4_num*cs_per_slide];
    Dy = M4_WIDTH*m4_num + M4_SPACING*(m4_num+1) + CS_HEIGHT;
    int py = M4_WIDTH + M4_SPACING;
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < m4_num; j++){
            string inst_name = "Metal4_port_" + to_string(i*m4_num + j);
            string layer = "ME4";
            int x1 = 0;
            int x2 = die_x2;
            int y1 = i*Dy + py*j;
            int y2 = y1 + M4_WIDTH;
            ME4_specialnet_port[i*m4_num + j] = SpecialNet(inst_name, layer, x1, y1, x2, y2);
        }
    }

    //Step 6: create Via34 from ME4 drain
    //drain to ME3
    Component** Via34_drain2ME3 = new Component*[cs_per_slide];
    for(int i = 0; i < cs_per_slide; i++) Via34_drain2ME3[i] = new Component[cs_per_slide];
    for(int i = 0; i < num_m4_drain; i++){
        for(int j = 0; j < num_m4_drain; j++){
            string lib_name = VIA34_LIB_NAME;
            //left bottom corner units
            string inst_name = "Via34_drain2ME3_" + to_string(i*num_m4_drain + j + 0*sorce_num);
            int x = ME3_specialnet[i][j].x1;
            int y = cs_array[i][j].y + CS_Y1_TO_DRAIN;
            Via34_drain2ME3[i][j] = Component(lib_name, inst_name, x, y);
            //right bottom corner units
            inst_name = "Via34_drain2ME3_" + to_string(i*num_m4_drain + j + 1*sorce_num);
            x = ME3_specialnet[(cs_per_slide-1)-i][j].x1;
            y = cs_array[(cs_per_slide-1)-i][j].y + CS_Y1_TO_DRAIN;
            Via34_drain2ME3[(cs_per_slide-1)-i][j] = Component(lib_name, inst_name, x, y);
            //left top corner units
            inst_name = "Via34_drain2ME3_" + to_string(i*num_m4_drain + j + 2*sorce_num);
            x = ME3_specialnet[i][j].x1;
            y = cs_array[i][(cs_per_slide-1)-j].y + CS_Y1_TO_DRAIN;
            Via34_drain2ME3[i][(cs_per_slide-1)-j] = Component(lib_name, inst_name, x, y);
            //right top corner units
            inst_name = "Via34_drain2ME3_" + to_string(i*num_m4_drain + j + 3*sorce_num);
            x = ME3_specialnet[(cs_per_slide-1)-i][j].x1;
            y = cs_array[(cs_per_slide-1)-i][(cs_per_slide-1)-j].y + CS_Y1_TO_DRAIN;
            Via34_drain2ME3[(cs_per_slide-1)-i][(cs_per_slide-1)-j] = Component(lib_name, inst_name, x, y);
        }
    }
    //Step 7: create Via34 to ME4 port
    //port to ME4
    int num_port = sqrt(sorce_num);
    Component* Via34_port2ME3 = new Component[2*sorce_num];
    for(int i = 0; i < m4_num*cs_per_slide; i++){
        int column = i / m3_num;
        int j = i % m3_num;
        //left
        string lib_name = VIA34_LIB_NAME;
        string inst_name = "Via34_port2ME3_" + to_string(i);
        int x = ME3_specialnet[column][j].x1;
        int y = ME4_specialnet_port[i].y1;
        Via34_port2ME3[i] = Component(lib_name, inst_name, x, y);
        //right
        inst_name = "Via34_port2ME3_" + to_string(sorce_num+i);
        x = ME3_specialnet[(cs_per_slide-1)-column][j].x1;
        y = ME4_specialnet_port[i].y1;
        Via34_port2ME3[i+sorce_num] = Component(lib_name, inst_name, x, y);
    }

    
    //write info to def file
    vector<Component> component_list;
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < cs_per_slide; j++){
            component_list.push_back(cs_array[i][j]);
        }
    }

    //4. add 'Via34_port2ME3' component to 'component_list'
    for(int i = 0; i < 2*sorce_num; i++){
        component_list.push_back(Via34_port2ME3[i]);
    }

    vector<SpecialNet> specialnet_list;
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < m3_num; j++){
            specialnet_list.push_back(ME3_specialnet[i][j]);
        }
    }
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < cs_per_slide; j++){
            specialnet_list.push_back(ME4_specialnet_drain[i][j]);
        }
    }
    for(int i = 0; i < m4_num*cs_per_slide; i++){
        specialnet_list.push_back(ME4_specialnet_port[i]);
    }
    for(int i = 0; i < cs_per_slide; i++){
        for(int j = 0; j < cs_per_slide; j++){
            component_list.push_back(Via34_drain2ME3[i][j]);
        }
    }
    string def_name = argv[2];
    write_def(def_name, die, component_list, specialnet_list);
    
}